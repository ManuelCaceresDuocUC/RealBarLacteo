package com.whatsappbot.whatsappservice.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.whatsappbot.whatsappservice.model.PedidoEntity;
import com.whatsappbot.whatsappservice.repository.PedidoRepository;
import com.whatsappbot.whatsappservice.repository.ProductoStockRepository;
import com.whatsappbot.whatsappservice.service.PedidoContextService;
import com.whatsappbot.whatsappservice.service.TransbankService;
import com.whatsappbot.whatsappservice.service.WatiService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/webhook")
@RequiredArgsConstructor
@Slf4j
public class WebhookController {

    private final PedidoContextService pedidoContext;
    private final WatiService watiService;
    private final TransbankService transbankService;
    private final PedidoRepository pedidoRepository;
    private final ProductoStockRepository productoStockRepository;
    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${wati.api.key}")
    private String watiApiKey;

    private final Map<String, LocalDateTime> pedidosFinalizados = new ConcurrentHashMap<>();
    private final Map<String, Long> timestampUltimoResumen = new ConcurrentHashMap<>();

    @PostMapping("/wati")
public ResponseEntity<?> recibirMensaje(@RequestBody JsonNode payload) {
        String telefono = payload.path("waId").asText();
        String texto = payload.path("text").asText("");
        String tipo = payload.path("type").asText();
        String messageId = payload.path("whatsappMessageId").asText();
        // ✅ Ignorar triggers automáticos si ya hay un pedido pagado reciente
        if ("order".equalsIgnoreCase(tipo) && texto.equalsIgnoreCase("#trigger_view_cart")) {
// ✅ Ignorar si el trigger es muy antiguo (más de 2 minutos)
    long triggerTimestamp = payload.path("timestamp").asLong(0);
    long ahora = System.currentTimeMillis() / 1000;
    if (Math.abs(ahora - triggerTimestamp) > 120) {
        log.warn("⏳ Trigger ignorado por antigüedad para {}. Timestamp: {}", telefono, triggerTimestamp);
        return ResponseEntity.ok().build();
    }

    // 🔒 Ignorar si ya hay un pedido pagado reciente (últimos 5 minutos)
    Optional<PedidoEntity> ultimoPagado = pedidoRepository
        .findTopByTelefonoAndEstadoOrderByFechaCreacionDesc(telefono, "pagado");
    if (ultimoPagado.isPresent() && 
        ultimoPagado.get().getFechaCreacion().isAfter(OffsetDateTime.now(ZoneId.of("America/Santiago")).minusMinutes(5))) {
        log.warn("⛔ Trigger bloqueado por pedido pagado reciente para {}", telefono);
        return ResponseEntity.ok().build();
    }


    // ⏳ Ignorar si ya hay un pedido en proceso en memoria
    if (pedidoContext.pedidoTemporalPorTelefono.containsKey(telefono)) {
        log.info("🔁 Trigger ignorado: ya hay un pedido pendiente en memoria para {}", telefono);
        return ResponseEntity.ok().build();
    }

    log.info("🟢 Trigger recibido para validar stock de {}", telefono);

            String url = "https://live-mt-server.wati.io/442590/api/v1/getMessages/" + telefono;
            var headers = new HttpHeaders();
            headers.set("Authorization", "Bearer " + watiApiKey);
            var entity = new HttpEntity<>(headers);

            JsonNode mensajes;
            List<JsonNode> mensajesOrdenados = new ArrayList<>();
            String mensajeCarrito = null;
            int reintentos = 0;

            while (mensajeCarrito == null && reintentos < 20) {
                try {
                    TimeUnit.SECONDS.sleep(2);
                    var response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);
                    mensajes = response.getBody().path("messages").path("items");

                    if (mensajes == null || !mensajes.isArray()) {
                        reintentos++;
                        continue;
                    }

                    mensajesOrdenados.clear();
                    mensajes.forEach(mensajesOrdenados::add);
                    mensajesOrdenados.sort(Comparator.comparingLong(this::obtenerTimestamp));

                    for (JsonNode msg : mensajesOrdenados) {
                        long msgTimestamp = obtenerTimestamp(msg);
                        if (msgTimestamp <= triggerTimestamp) continue;

                        String finalText = msg.path("finalText").asText("");
                        String textMsg = msg.path("text").asText("");
                        String contenido = !finalText.isBlank() ? finalText : textMsg;
                        String contenidoLower = contenido.toLowerCase();

                        if (contenidoLower.contains("items del carrito:")) {
                            mensajeCarrito = contenido;
                            break;
                        }
                    }

                    if (mensajeCarrito == null) reintentos++;

                } catch (Exception e) {
                    log.error("❌ Error obteniendo mensaje del carrito", e);
                    reintentos++;
                }
            }

            if (mensajeCarrito == null) {
                watiService.enviarMensajeTexto(telefono, "❌ No se encontró el mensaje con los items del carrito. Intenta de nuevo.");
                log.warn("⚠️ Carrito no encontrado para {}. Trigger cancelado.", telefono);
                return ResponseEntity.ok().build();
            }

            String detalle = extraerDetalleFlexible(mensajeCarrito);
            List<String> productos = extraerProductosDesdeDetalle(detalle);

            if (productos.isEmpty()) {
                watiService.enviarMensajeTexto(telefono, "❌ No se detectaron productos válidos en tu carrito. Intenta nuevamente.");
                log.warn("⚠️ Carrito sin productos válidos para {}. Trigger cancelado.", telefono);
                return ResponseEntity.ok().build();
            }

            for (String producto : productos) {
                var stock = productoStockRepository.findByNombreIgnoreCase(producto);
                if (stock.isEmpty() || !stock.get().getDisponible()) {
                    String advertencia = "❌ El producto '" + producto + "' no está disponible. Por favor edita tu pedido.";
                    watiService.enviarMensajeTexto(telefono, advertencia);
                    log.warn("🚫 Producto sin stock '{}' detectado en carrito de {}. Pedido descartado.", producto, telefono);

                    pedidoContext.pedidoTemporalPorTelefono.remove(telefono);
                    pedidoContext.indicacionPreguntadaPorTelefono.remove(telefono);

                    return ResponseEntity.ok().build();
                }
            }

            PedidoEntity pedido = new PedidoEntity();
            String pedidoId = "pedido-" + UUID.randomUUID().toString().substring(0, 18);
            pedido.setPedidoId(pedidoId);
            pedido.setTelefono(telefono);
            pedido.setDetalle(detalle);
            pedidoContext.pedidoTemporalPorTelefono.put(telefono, pedido);

            watiService.enviarMensajeTexto(telefono, "✅ Stock verificado\nCONTINUAR");
            watiService.enviarMensajeBotones(
                telefono,
                "¿Deseas agregar una indicación especial al pedido?",
                "Puedes personalizarlo",
                "",
                List.of("Sí", "No")
            );
            pedidoContext.indicacionPreguntadaPorTelefono.put(telefono, true);

            log.info("✅ Pedido válido inicializado en memoria para {} con ID {}", telefono, pedidoId);

            return ResponseEntity.ok().build();
        }

        if ("interactive".equalsIgnoreCase(tipo)) {
            JsonNode btn = payload.path("interactiveButtonReply");
            String title = btn.path("title").asText("").toLowerCase();
            if (title.equals("sí")) {
                log.info("✍️ Cliente {} eligió agregar indicación personalizada", telefono);
                watiService.enviarMensajeTexto(telefono, "✍️ Por favor escribe tu indicación a continuación.");
                return ResponseEntity.ok().build(); // Esperar mensaje libre
            }

            if (title.equals("no")) {
                log.info("🚫 Cliente {} no desea agregar indicación personalizada", telefono);
                return ResponseEntity.ok().build(); // WATI se encargará de enviar los botones de local
            }

            if (title.equals("hyatt") || title.equals("charles")) {
                String localNormalizado = title.equals("hyatt") ? "HYATT" : "CHARLES";
                log.info("✅ Local {} asignado al pedido temporal de {}", localNormalizado, telefono);

                PedidoEntity pedido = pedidoContext.pedidoTemporalPorTelefono.get(telefono);
                if (pedido == null) {
                    watiService.enviarMensajeTexto(telefono, "⚠️ No se encontró un pedido pendiente en memoria. Intenta de nuevo desde el carrito.");
                    return ResponseEntity.ok().build();
                }

                pedido.setLocal(localNormalizado);

                String url = "https://live-mt-server.wati.io/442590/api/v1/getMessages/" + telefono;
                var headers = new HttpHeaders();
                headers.set("Authorization", "Bearer " + watiApiKey);
                var entity = new HttpEntity<>(headers);

                JsonNode mensajes;
                List<JsonNode> mensajesOrdenados = new ArrayList<>();
                String mensajeResumen = null;
                String indicacion = pedido.getIndicaciones();
                long triggerTimestamp = payload.path("timestamp").asLong(0);
                int reintentos = 0;
                long resumenTimestamp = 0;

                while (mensajeResumen == null && reintentos < 15) {
                    try {
                        var response = restTemplate.exchange(url, HttpMethod.GET, entity, JsonNode.class);
                        mensajes = response.getBody().path("messages").path("items");

                        if (mensajes == null || !mensajes.isArray()) {
                            TimeUnit.SECONDS.sleep(2);
                            reintentos++;
                            continue;
                        }

                        mensajesOrdenados.clear();
                        mensajes.forEach(mensajesOrdenados::add);
                        mensajesOrdenados.sort(Comparator.comparingLong(this::obtenerTimestamp));

                        for (JsonNode msg : mensajesOrdenados) {
                            long msgTimestamp = obtenerTimestamp(msg);
                            if (msgTimestamp <= triggerTimestamp) continue;

                            String finalText = msg.path("finalText").asText("");
                            String textMsg = msg.path("text").asText("");
                            String contenido = !finalText.isBlank() ? finalText : textMsg;
                            String contenidoLower = contenido.toLowerCase();

                            if (contenidoLower.contains("desde el carrito") && contenidoLower.contains("total estimado")) {
                                mensajeResumen = contenido;
                                resumenTimestamp = msgTimestamp;
                            }
                            if (contenidoLower.startsWith("indicacion:") && indicacion == null) {
                                indicacion = contenido.substring(contenido.indexOf(":" ) + 1).trim();
                            }
                        }

                        if (mensajeResumen == null) {
                            TimeUnit.SECONDS.sleep(2);
                            reintentos++;
                        }

                    } catch (Exception e) {
                        log.error("❌ Error obteniendo mensaje resumen", e);
                        reintentos++;
                    }
                }

                String detalle = extraerDetalleFlexible(mensajeResumen);
                double monto = extraerMontoFlexible(mensajeResumen);
                if (detalle == null || monto <= 0) {
                    watiService.enviarMensajeTexto(telefono, "❌ No se pudo procesar el pedido. Intenta nuevamente desde el carrito.");
                    return ResponseEntity.ok().build();
                }

                pedido.setDetalle(detalle);
                pedido.setIndicaciones(indicacion);
                pedido.setMonto( monto);
                pedido.setEstado("pendiente");
                pedidoRepository.save(pedido);

                var pago = transbankService.generarLinkDePago(pedido.getPedidoId(), monto);
                pedido.setLinkPago(pago.getUrl());
                pedido.setTokenWs(pago.getToken());
                pedidoRepository.save(pedido);

                try {
                    watiService.enviarMensajePagoEstatico(telefono, pedido.getMonto(), pago.getUrl());
                } catch (IOException e) {
                    e.printStackTrace();
                }

                pedidoContext.pedidoTemporalPorTelefono.remove(telefono);
                pedidoContext.indicacionPreguntadaPorTelefono.remove(telefono);
                pedidoContext.ultimoMensajeProcesadoPorNumero.put(telefono, messageId);
                pedidosFinalizados.put(telefono, LocalDateTime.now());
                timestampUltimoResumen.put(telefono, resumenTimestamp);

                log.info("✅ Pedido confirmado y link generado para {}. Monto: {}", telefono, monto);
            }
        }
        if ("text".equalsIgnoreCase(tipo)) {
            if (pedidoContext.indicacionPreguntadaPorTelefono.containsKey(telefono) &&
                pedidoContext.pedidoTemporalPorTelefono.containsKey(telefono)) {

                String textoLower = texto.trim().toLowerCase();

                // Ignora respuestas típicas que no son indicación
                if (!textoLower.contains("trigger") && !textoLower.equals("sí") && !textoLower.equals("no")) {
                    PedidoEntity pedido = pedidoContext.pedidoTemporalPorTelefono.get(telefono);
                    pedido.setIndicaciones(texto.trim());
                    log.info("✍️ Indicaciones recibidas para {}: {}", telefono, texto.trim());
                }
            }
        }

        return ResponseEntity.ok().build();
    }

    private String extraerDetalleFlexible(String texto) {
        try {
            String[] lineas = texto.split("\n");
            StringBuilder sb = new StringBuilder();
            for (String linea : lineas) {
                if (linea.contains("×")) {
                    sb.append(linea.trim()).append("\n");
                }
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return null;
        }
    }

    private List<String> extraerProductosDesdeDetalle(String detalle) {
        List<String> productos = new ArrayList<>();
        if (detalle == null) return productos;
        for (String linea : detalle.split("\n")) {
            if (linea.contains("×")) {
                String[] partes = linea.split("×");
                if (partes.length == 2) {
                    productos.add(partes[1].trim().toLowerCase());
                }
            }
        }
        return productos;
    }

    private int extraerMontoFlexible(String texto) {
        try {
            int inicio = texto.indexOf("{\"Total\":");
            int fin = texto.indexOf("}", inicio);
            if (inicio != -1 && fin != -1) {
                String jsonStr = texto.substring(inicio, fin + 1);
                ObjectMapper mapper = new ObjectMapper();
                JsonNode node = mapper.readTree(jsonStr);
                return (int) node.path("Total").asDouble(0);
            }
        } catch (Exception e) {
            log.error("❌ Error extrayendo el monto", e);
        }
        return -1;
    }

    private long obtenerTimestamp(JsonNode msg) {
        if (msg.has("timestamp")) return msg.path("timestamp").asLong(0);
        if (msg.has("created")) {
            try {
                return java.time.Instant.parse(msg.path("created").asText("")).getEpochSecond();
            } catch (Exception e) {
                return 0;
            }
        }
        return 0;
    }
}