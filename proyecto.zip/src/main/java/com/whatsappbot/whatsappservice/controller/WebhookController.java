package com.whatsappbot.whatsappservice.controller;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.whatsappbot.whatsappservice.dto.PagoResponseDTO;
import com.whatsappbot.whatsappservice.model.PedidoEntity;
import com.whatsappbot.whatsappservice.repository.PedidoRepository;
import com.whatsappbot.whatsappservice.service.TransbankService;
import com.whatsappbot.whatsappservice.service.WatiService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/webhook")
@RequiredArgsConstructor
public class WebhookController {

    private final WatiService watiService;
    private final PedidoRepository pedidoRepository;
    private final TransbankService transbankService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    @PostMapping("/wati")
    public ResponseEntity<?> recibirMensaje(@RequestBody JsonNode payload) {
        log.info("📥 Payload recibido: {}", payload.toPrettyString());

        try {
            String tipo = payload.path("type").asText("");
            String telefono = payload.path("waId").asText("");
            String nombre = payload.path("senderName").asText("Cliente");

            if ("text".equalsIgnoreCase(tipo)) {
                String texto = payload.path("text").asText("").toLowerCase();
                log.info("📥 Mensaje de texto: {} desde {}", texto, telefono);

                if (texto.contains("ayuda")) {
                    watiService.enviarTemplateAyuda(telefono, nombre);
                }

                boolean contieneJsonDeTotal = texto.contains("\"total\"") && texto.contains("×");
                if (contieneJsonDeTotal) {
                    Pattern patternJson = Pattern.compile("\\{.*?\"Total\":\"(\\d+(\\.\\d+)?)\".*?\\}");
                    Matcher matcher = patternJson.matcher(texto);

                    int monto = 1000;
                    String detalle = texto;

                    if (matcher.find()) {
                        monto = (int) Double.parseDouble(matcher.group(1));
                        log.info("✅ Monto extraído del resumen: {}", monto);
                    } else {
                        log.warn("❌ No se pudo extraer el monto desde el texto del carrito.");
                    }

                    PedidoEntity pedidoExistente = pedidoRepository.findFirstByTelefonoAndEstado(telefono, "pendiente");
                    if (pedidoExistente != null) {
                        log.warn("⚠️ Ya existe un pedido pendiente para el número {}", telefono);
                        String linkPagoExistente = pedidoExistente.getLinkPago();
                        if (linkPagoExistente != null && !linkPagoExistente.isBlank()) {
                            watiService.enviarMensajePagoEstatico(telefono, (double) monto, linkPagoExistente);
                        }
                        return ResponseEntity.ok().build();
                    }

                    String pedidoId = "pedido-" + UUID.randomUUID().toString().substring(0, 8);
                    PedidoEntity pedido = new PedidoEntity();
                    pedido.setPedidoId(pedidoId);
                    pedido.setTelefono(telefono);
                    pedido.setDetalle(detalle);
                    pedido.setEstado("pendiente");
                    pedidoRepository.save(pedido);

                    PagoResponseDTO pago = transbankService.generarLinkDePago(pedidoId, monto);
                    String linkPago = pago.getUrl();
                    pedido.setLinkPago(linkPago);
                    pedidoRepository.save(pedido);

                    // Generar comanda en PDF
String urlComanda = watiService.generarComandaYPDF(telefono, pedidoId, detalle);
log.info("🧾 Comanda generada y almacenada: {}", urlComanda);

watiService.enviarMensajePagoEstatico(telefono, (double) monto, linkPago);
                }
            }

        } catch (Exception e) {
            log.error("❌ Error procesando webhook", e);
        }

        return ResponseEntity.ok().build();
    }
}
