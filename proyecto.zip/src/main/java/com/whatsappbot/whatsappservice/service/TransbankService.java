package com.whatsappbot.whatsappservice.service;

import cl.transbank.webpay.common.WebpayOptions;
import cl.transbank.webpay.webpayplus.WebpayPlus.Transaction;
import cl.transbank.webpay.webpayplus.responses.TransactionCreateResponse;
import cl.transbank.common.IntegrationType;
import com.whatsappbot.whatsappservice.dto.PagoResponseDTO;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import cl.transbank.webpay.webpayplus.responses.TransactionCommitResponse;


import java.util.UUID;

@Service
public class TransbankService {

    private static final Logger log = LoggerFactory.getLogger(TransbankService.class);

    private final String commerceCode = System.getenv("TRANSBANK_COMMERCE_CODE");
    private final String apiKey = System.getenv("TRANSBANK_API_KEY");
    private final String returnUrl = System.getenv("TRANSBANK_RETURN_URL");

    @PostConstruct
    public void verificarVariablesEntorno() {
        log.info("🔍 Verificando variables de entorno...");
        if (commerceCode == null || apiKey == null || returnUrl == null) {
            throw new IllegalStateException("❌ Variables de entorno TRANSBANK no configuradas correctamente.");
        }
        log.info("TRANSBANK_COMMERCE_CODE: {}", commerceCode);
        log.info("TRANSBANK_API_KEY: {}", "[CARGADA]");
        log.info("RETURN_URL: {}", returnUrl);
    }
    public TransactionCommitResponse confirmarTransaccion(String token) throws Exception {
    WebpayOptions options = new WebpayOptions(commerceCode, apiKey, IntegrationType.TEST);
    Transaction tx = new Transaction(options);
    return tx.commit(token);
}

    public PagoResponseDTO generarLinkDePago(String buyOrder, int amount) {
        try {
            String sessionId = UUID.randomUUID().toString();
            WebpayOptions options = new WebpayOptions(commerceCode, apiKey, IntegrationType.TEST);
            Transaction tx = new Transaction(options);

            TransactionCreateResponse response = tx.create(buyOrder, sessionId, amount, returnUrl);
            return new PagoResponseDTO(response.getUrl(), response.getToken());

        } catch (Exception e) {
            log.error("❌ Error al crear la transacción Webpay: {}", e.getMessage(), e);
            throw new RuntimeException("Error al generar el link de pago con Transbank");
        }
    }
}
